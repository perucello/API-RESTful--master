create table cliente (
	id SERIAL PRIMARY KEY,
	nome varchar(60) NOT NULL,
	email varchar(100) NOT NULL,
	telefone varchar (100) NOT NULL
	
);