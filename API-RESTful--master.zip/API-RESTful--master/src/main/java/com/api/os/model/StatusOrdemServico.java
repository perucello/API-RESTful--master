package com.api.os.model;

public enum StatusOrdemServico {
	
	ABERTA, FINALIZADA, CANCELADA

}
